<?php

	$aCouleurs = array(	"gris" => array("nom"=>"Gris", "code" => "#444444"), 
						"rouge" => array("nom"=>"Rouge pure", "code" => "#FF0000"), 
						"vert" => array("nom"=>"Vert émeraude", "code" => "#00FF00"), 
						"bleu" => array("nom"=>"bleu pure", "code" => "#0000FF"), 
						"test"=> array("nom"=>"Couleur aléatoire", "code" => "#23FF89")
					);

	if(!isset($_POST['couleur']))
	{
		$couleur_bg = '#FFFFFF';
	}
	else
	{
		$cle_couleur = $_POST['couleur'];
		/*$maCouleur = $aCouleurs[$cle_couleur];
		var_dump($maCouleur);
		$couleur_bg = $maCouleur['code'];
*/
		$couleur_bg = $aCouleurs[$cle_couleur]['code'];
	}

	/*echo "GET";
	var_dump($_GET);
	echo "<br>";
	echo "POST";
	var_dump($_POST);

	echo "<br>";*/
	
 ?>


<html>
<head>
	<meta charset="utf-8">
	<title>Cours 15 : Encore des chaines et des tableaux </title>
	<style>
		body{
			background-color: <?php echo $couleur_bg ?>;
		}
	</style>
<head>


<body class="">
	<h1>Formulaire</h1>
	<form action="formulaire.php?couleur=jonathan" method="post">

		<p>Nom : <input type="text" name="nom"></p>
		<p><input type="number" name="date"></p>
		<p><input type="radio" name="genre" value="f">F</p>
		<p><input type="radio" name="genre" value="m">M</p>
		<p><input type="radio" name="genre" value="a">Autre</p>

		<p><input type="checkbox" name="sport[]" value="cap">Course à pied</p>
		<p><input type="checkbox" name="sport[]" value="ski">Ski</p>
		<p><input type="checkbox" name="sport[]" value="natation">Natation</p>

		<?php
			foreach ($aCouleurs as $cle => $infoCouleur) 
			{
				//if($codeCouleur != $couleur_bg)
				//{
					echo '<p>'. $infoCouleur['nom'] .' : <input type="radio" value="'. $cle . '" name="couleur"></p>';
				//}
			}
		?>

		<input type="submit" name="">
	</form>
</body>
</html>











